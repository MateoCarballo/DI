public class Main {
    public static void main(String[] args) {
      VentanaTeclado vt = new VentanaTeclado();
    }
}