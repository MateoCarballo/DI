package Vista;

public class VentanaTrabajador {
}
