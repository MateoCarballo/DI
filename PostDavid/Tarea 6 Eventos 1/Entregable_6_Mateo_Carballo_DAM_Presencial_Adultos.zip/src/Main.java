import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        Principal p = new Principal();
    }
}
// TODO En VentanJSlider no se como hacer para que la ventana con 3 botones se mantenga despues de elegir una de las opciones