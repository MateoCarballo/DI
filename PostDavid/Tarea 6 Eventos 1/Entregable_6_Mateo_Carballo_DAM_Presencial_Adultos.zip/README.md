# OBJETIVO DE LA TAREA 

![image.png](res%2Fimage.png)

Basado no exercicio anterior engade as interacions necesarias para que:

Mostrar o valor seleccionado das opcións de xénero.
Mostrar o valor seleccionado do ComboBox nunha etiqueta e no textArea.
Engadir no menú opcions para poder executar outra clase e facer modificacións nun componente, de texto ou/e cor.
Engadir un boton onde poidas escoller entre tres opcións. Cada unha delas mostrará a opción escollida sendo a 3ª a de peche do programa.
NOTA: non se terán en conta os iconos do frame.